const express = require("express");
const bodyParser = require("body-parser");
const moment = require("moment");

const app = express();

const PORT = process.env.PORT || 8000;

app.use(bodyParser.json());

app.post('/hello', async (req, res) => {
  return res.json({
    hello: "world"
  });
});
app.post('/createSlots', async (req, res) => {
  console.log(req)
  async function getTimeStops(start, end, interval){
    const startTime = moment(start, 'HH:mm:ss');
    const endTime = moment(end, 'HH:mm:ss');

    if( endTime.isBefore(startTime) ){
      endTime.add(1, 'day');
    }

    const timeStops = [];

    while(startTime <= endTime){
      timeStops.push(new moment(startTime).format('HH:mm:ss'));
      startTime.add(interval, 'minutes');
    }
    return timeStops;
  }

  const timeStops = await getTimeStops(req.payload.event.data.new.start_time, req.payload.event.data.new.end_time);
  console.log('timeStops ', timeStops);

  // insert into db
  const HASURA_MUTATION = `
      mutation ($start_time: time!, $end_time: time!, $facility_id: Int!) {
        insert_slots(objects: {start_time: $start_time, end_time: $end_time, facility_id: $facility_id}) {
          affected_rows
        }
      }
    `;
  const variables = { start_time: start_time, end_time: end_time, facility_id: id };

  // execute the parent mutation in Hasura
  require('axios')({
    url: 'http://graphql-engine:8080/v1/graphql',
    method: 'post',
    data: {
      query: HASURA_MUTATION,
      variables
    },
    headers: {
      "x-hasura-admin-secret": "SurfATurf"
    }
  })
    .then(resp => {
      if ('errors' in resp.data) {
        return res.status(400).json({
          message: resp.data.errors[0].message
        })
      }
      return res.json(resp.data.data.insert_images_one);
    })
    .catch(err => {
      return res.status(400).json({
        message: err.message
      })
    });
  return res.json({
    hello: "world"
  });
});

app.listen(PORT);
